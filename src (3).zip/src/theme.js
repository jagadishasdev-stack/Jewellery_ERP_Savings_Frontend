import { Favorite } from "@mui/icons-material";
import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  // General
  typography: {
    fontFamily: "Inter, sans-serif",
  },

  palette: {
    primary: {
      main: "#422e5d", // Royal Purple from Jain Gold logo
    },
    secondary: {
      main: "#B98A46", // Gold from Jain Gold logo
    },
    success: {
      main: "#4caf50", // green
    },
    danger: {
      main: "#f44336", // red
    },
    neutral: {
      main: "#64748B", // gray-blue
      contrastText: "#fff",
    },
    background: {
      default: "#ffff",
      paper: "#f4f6f8",
    },
  },

  customColors: {
    sidebarBg: "#111827",
    footerBg: "#eeeeee",
    menuHover: "#e0f7fa",
    planbg: "#f5ebcf",
  },

  colors: {
    primaryHeading: "#422e5d",
    subHeading: "#422e5d",
    primaryButton: "#B98A46",
    bordercolor: "#E0CBB6",
    sidebarbg: "#f1f1f1", // not present in theme2 source, kept from theme1
    menuButton: "#f5ac19", // not present in theme2 source, kept from theme1
  },

  // Component Specific
  // Dashboard screen
  dashboard: {
    dashboardScreenBg: "#f5f5f5",
  },

  theme2: {
    favorite: "#fd0059",
    headerBg: "#ffffff",
    productCardBg: "#F8F0DD",
    notificationBadge: "#694895",
    secondaryBg: "#FFF7EC",
    borderCol: "#CECBC7",
    digiGoldbg: "#FEE498",

    digi_card_bg:
      "linear-gradient(131deg, #422e5d 0%, #7c5ba8 50%, #B98A46 100%)",

    primaryHeading: "#422e5d",
    offersCardBg: "#422e5d",
    secondaryHeading: "#565350",
    textCol: "#422e5d",
    textCol2: "#B98A46",

    loginBtn: "linear-gradient(90deg, #422e5d 0%, #B98A46 100%)",

    productCardGradient: "linear-gradient(90deg, #422e5d 0%, #B98A46 100%)",

    gradient: [
      "linear-gradient(180deg, #422e5d 0%, #211631 100%)", // Deep Purple
      "linear-gradient(180deg, #422e5d 0%, #B98A46 100%)", // Purple → Gold
      "linear-gradient(180deg, #B98A46 0%, #E7AD4B 100%)", // Gold → Light Gold
      "linear-gradient(180deg, #211631 0%, #B98A46 100%)", // Dark Purple → Gold
    ],
    primaryButton: "#B98A46",
    selectPlan: {
      primaryBtn: "linear-gradient(141deg, #422e5d 0%, #B98A46 80%)",
    },
  },

  // Plans screen
  plans: {
    cardBg: "#FFF7EC",
    cardBorderCol: "#E0CBB6",
    enrollBtnTxt: "#FFFEFA",
    gradient:
      "linear-gradient(90deg, #422e5d, #B98A46, #E7AD4B, #B98A46, #422e5d)",
    cardBg3: "#B98A46",
  },

  // Plan calculation screen
  calculatePlans: {
    textCol: "#544E49",
    mahaBenefitBgc: "#B98A46",
    investmentBgc: "#ffeee3",
    amountBg: "#FFF1DE",
    sliderBarCol: "#F2D7B1",
    sliderThumbBorderCol: "#B98A46",
    calculateCardGradient1: "#FEE7E2",
    calculateCardGradient2: "#FFF8D9",
    enrollBtnBg: "#422e5d",
  },

  // Payment and Ledger screen
  paymentAndLedger: {
    payInfoTextCol: "#857D75",
    payInfoTabSectionBg: "#FFFEFA",
    payInfoTabColActive: "#422e5d",
  },

  // Payment screen
  paymentScreen: {
    textColHighlighted: "#422e5d",
    amountColHighlighted: "#422e5d",
    textCol: "#544E49",
    sectionSeparatorLineCol: "#DFDFDF",
    cardBorder: "#E0CBB6",
    payBtnBg: "#B98A46",
    successText: "#5FAC50",
    warnText: "#FB6129",
    goldCon: "#B98A46",
    cardBgHighlighted: "#F4DFAC",
    userInfoCardBg: "#FFF1DE",
  },

  // Ledger screen
  ledger: {
    primaryTextCol: "#544E49",
    secondaryTextCol: "#857D75",
    ledgerListSeparatorLineCol: "#F3E8DD",
    amountPaidLabelBg: "#E1F9D9",
    amountPaidLabelTextCol: "#5A804D",
    downloadIconCol: "#7B61FF",
  },

  //Saving contact details
  savingContactDetails: {
    primaryTextCol: "#544E49",
    secondaryTextCol: "#B98A46",
  },

  // No saving plans screen
  noAddedPlans: {
    textCol: "#544E49",
    fillCol: "#B98A46",
    enrollNowCardBgCol: "#FFFBE9",
    enrollNowCardBorderCol: "#E0CBB6",
    giftCardSeeMoreTextCol: "#BB212199",
    trendingCardBgCol: "#FFEFDD",
  },

  // Cart screen
  cartScreen: {
    activeColor: "#B98A46",
    textColor: "#422e5d",
    connectorLineFallbackColor: "#ddd",
    circularIconFallbackColor: "#ccc",
    totalSummaryCardBgCol: "#FFF",
    totalSummaryCardBoxShadow: "0 -2px 10px rgba(0,0,0,0.08)",
    proceedToAddressBtnHoverCol: "#422e5d",
  },

  // Cart card
  cartCard: {
    cardBgCol: "#FFF",
    cardBoxShadow: "0 2px 8px rgba(0,0,0,0.08)",
    itemNameCol: "#222",
    itemSalePriceCol: "#B98A46",
    itemActualPriceCol: "#aaa",
    itemQtyContainerBgCol: "#B98A46",
    itemQtyContainerTextCol: "#FFF",
    itemQtyManagerBgCol: "#FFF",
    itemQtyManagerTextCol: "#000",
  },

  // Categories page
  categoriesPage: {
    categoryHeadingCol: "#422e5d",
    skipCategoryTextCol: "#B98A46",
  },

  // Category product
  categoryProduct: {
    searchBarBGCol: "#f3f3f3",
    searchIconFillCol: "#422e5d",
    searchBarBorderCol: "#FFF",
    searchBarFieldsetCol: "#C1C1C1",
    filterAndSortIconBorderCol: "#8A8A8A",
    filterAndSortIconFillCol: "#422e5d",
    selectedFilterBorderCol: "#B98A46",
    selectedFilterTextCol: "#422e5d",
    noProductTextCol: "#C1C1C1",
  },

  // Sort screen
  sortScreen: {
    overlayBGCol: "rgba(0, 0, 0, 0.3)",
    sortSectionBGCol: "rgba(255,255,255,0.8)",
    sortSectionBoxShadow: "rgba(0,0,0,0.15)",
    sortSectionHeaderBorderBottomCol: "rgba(0,0,0,0.1)",
    activeSortOptionBorderCol: "#B98A46",
    inactiveSortOptionBorderCol: "#B7B7B7",
    activeSortOptionTextCol: "#333",
  },

  // Filter screen
  filterScreen: {
    filterLabelSectionBGCol: "#EBEBEB",
    activeFilterNameBGCol: "#FFF",
    activeFilterNameTextCol: "#422e5d",
    inactiveFilterNameBGCol: "#EBEBEB",
    inactiveFilterNameTextCol: "#000",
    activeFilterOptionBorderCol: "#B98A46",
    inactiveFilterOptionBorderCol: "#CACACA",
    filterOptionBGCol: "#FFF",
    cancelBtnBGCol: "#A83232",
    cancelBtnTextCol: "#FFF",
    applyBtnBGCol: "#422e5d",
    applyBtnTextCol: "#FFF",
  },

  // Not present in theme2 source — kept unchanged from theme1
  digiTheme: {
    // Gold
    goldAccent: "#B98A46",
    goldBadgeBg: "#FFF5E1",
    goldBadgeText: "#7A5B22",
    goldBadgeIcon: "#B98A46",
    goldEnrolledBannerBg: "#FFF8EC",
    goldEnrolledBannerBorder: "#B98A46",
    goldEnrolledBannerLabel: "#7A5B22",
    goldToggleBg: "#FFF5E1",
    goldToggleBorder: "#B98A46",
    goldToggleText: "#7A5B22",
    goldShadow: "rgba(185, 138, 70, 0.15)",

    // Silver
    silverAccent: "#5E6E7A",
    silverBadgeBg: "#F0F4F8",
    silverBadgeText: "#334155",
    silverBadgeIcon: "#5E6E7A",
    silverEnrolledBannerBg: "#F0F4F8",
    silverEnrolledBannerBorder: "#94A3B8",
    silverEnrolledBannerLabel: "#334155",
    silverToggleBg: "#E2E8F0",
    silverToggleBorder: "#94A3B8",
    silverToggleText: "#1E293B",

    // Common
    rateTextColor: "#1A1A1A",
    purityTextColor: "#757575",
    cardBorder: "#E5D8C4",
    cardBg: "#FFFFFF",
    whyInvestIconBg: "#FFFDF9",
    bodyText: "#424242",
    labelText: "#757575",
    dividerColor: "#EEEEEE",
    dialogBg: "rgba(255, 255, 255, 0.95)",
    dialogBorder: "rgba(185, 138, 70, 0.2)",
    backdropBg: "rgba(0, 0, 0, 0.5)",
    closeButtonBg: "rgba(0, 0, 0, 0.04)",
    closeButtonHover: "rgba(0, 0, 0, 0.08)",
    memberHoverBg: "rgba(185, 138, 70, 0.05)",
    disabledBtn: "#E0E0E0",
    warningDialogBg: "#FFFFFF",
  },

  // ─── E-COMMERCE ────────────────────────────────────────────────────────────
  // Not present in theme2 source — kept unchanged from theme1
  ecommerce: {
    // Brand palette
    gold: "#B98A46",
    ink: "#1A1A1A",
    inkSoft: "#565350",
    muted: "#8A8A8A",
    line: "#ECE6DB",
    surface: "#FFFFFF",
    surfaceAlt: "#FAF7F1",
    cream: "#FFFDF9",
    imgBg: "#F4F1EC",

    gradient: "linear-gradient(180deg, #B22222 0%, #241c0e 100%)",

    fontBody: "Inter, system-ui, sans-serif",
    fontDisplay: "Inter, system-ui, sans-serif",

    radius: {
      card: "16px",
      tile: "20px",
      sheet: "24px",
      pill: "999px",
      sm: "10px",
    },

    shadow: {
      sm: "0 1px 4px rgba(24,20,12,0.06)",
      md: "0 4px 16px rgba(24,20,12,0.08)",
      lg: "0 10px 30px rgba(24,20,12,0.12)",
      bar: "0 -6px 24px rgba(24,20,12,0.10)",
    },

    activeColor: "#996515",
    textColor: "#4b0000",
    proceedBtnHoverCol: "#7a4b12",
    summaryCardBoxShadow: "0 -2px 10px rgba(0,0,0,0.08)",

    sectionHeadingCol: "#565350",
    viewAllCol: "#500004",
  },
});

export default theme;
