

// export default APP_CONFIG;
const APP_CONFIG = {
  STORE_ID: 772,
  THEME_ID: 3,
  appid: "com.asterix.jain",
  appleid: "6760403859",

  DEFAULT_BRANCH: "JAIN",
  BRANCH: "JAIN",
  STORE_NAME: "Jain Gold",
  app_name: "Jain Gold",

  // Alpha-tag store: this store identifies stock by tagno_alpha. Sent as
  // is_alpha on every e-com API call so the backend knows which column the
  // tagno value refers to (1 = alpha, 0 = numeric). Per-store build constant.
  IS_ALPHA: 1
};

export default APP_CONFIG;
