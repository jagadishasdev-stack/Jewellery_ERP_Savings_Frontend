#!/usr/bin/env node
/* eslint-disable no-console */
// ─── rebrand.js ───────────────────────────────────────────────────────────────
// One-command white-label rebrand for this Capacitor app.
//
//   Usage:  node scripts/rebrand.js            (uses scripts/rebrand.config.json)
//           node scripts/rebrand.js path/to/other-config.json
//
// Two separate name fields drive the rename:
//   • appName    → the launcher / activity display name (app_name). Applied
//                  ONLY to constants.js app_name + strings.xml app_name /
//                  title_activity_main.
//   • STORE_NAME → the brand store name used everywhere else (capacitor
//                  appName, assets capacitor.config.json appName, and
//                  constants.js STORE_NAME).
//
// What it changes (from the current brand → the config's brand):
//   1. capacitor.config.ts ................ appId, appName(←STORE_NAME)
//   2. android/app/src/main/AndroidManifest.xml ... package=""
//   3. android/app/src/main/res/values/strings.xml  app_name(←appName),
//      title_activity_main(←appName), package_name, custom_url_scheme
//   4. android/app/build.gradle ........... namespace, applicationId,
//                                           versionCode, versionName
//   5. src/config/constants.js ............ appid, STORE_NAME(←STORE_NAME),
//      app_name(←appName)
//      (+ STORE_ID / BRANCH / THEME_ID / appleid only if set in the config)
//   6. android/app/src/main/assets/capacitor.config.json  appId,
//      appName(←STORE_NAME)
//      (also auto-regenerated later by `npx cap sync`)
//   7. Java sources: rewrites `package <old>;` and MOVES
//      android/app/src/main/java/<old/path> → java/<new/path>
//
// Safety: all files are read + verified FIRST; nothing is written unless every
// expected pattern is found. Exits non-zero with a clear message otherwise.
//
// Note: the native Android package is detected from android/app/build.gradle,
// NOT assumed to equal capacitor.config.ts's appId. The two drift whenever a
// past rebrand only touched the web side, and assuming they match makes every
// native pattern miss and aborts the whole run.

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const rel = (p) => path.relative(ROOT, p).replace(/\\/g, "/");

// ── 1. Load config ────────────────────────────────────────────────────────────
const configPath = path.resolve(
  ROOT,
  process.argv[2] || "scripts/rebrand.config.json",
);
if (!fs.existsSync(configPath)) {
  console.error(`✖ Config not found: ${configPath}`);
  process.exit(1);
}
const cfg = JSON.parse(fs.readFileSync(configPath, "utf8"));

for (const key of ["appId", "appName", "STORE_NAME", "versionCode", "versionName"]) {
  if (cfg[key] === undefined || cfg[key] === "") {
    console.error(`✖ Config is missing required field "${key}"`);
    process.exit(1);
  }
}
if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(cfg.appId)) {
  console.error(`✖ "${cfg.appId}" is not a valid Android application ID`);
  process.exit(1);
}

// ── 2. Detect the CURRENT brand from capacitor.config.ts ────────────────────
const capConfigPath = path.join(ROOT, "capacitor.config.ts");
const capConfigSrc = fs.readFileSync(capConfigPath, "utf8");
const oldId = capConfigSrc.match(/appId:\s*["']([^"']+)["']/)?.[1];
const oldName = capConfigSrc.match(/appName:\s*["']([^"']+)["']/)?.[1];
if (!oldId || !oldName) {
  console.error("✖ Could not detect current appId/appName in capacitor.config.ts");
  process.exit(1);
}

// ── 2b. Detect the CURRENT native package from android/app/build.gradle ─────
// This is the source of truth for the Android side. It can differ from the
// Capacitor appId above, so never derive native patterns from oldId.
const gradleFile = "android/app/build.gradle";
const gradlePath = path.join(ROOT, gradleFile);
let oldAndroidId = oldId;
if (fs.existsSync(gradlePath)) {
  const gradleSrc = fs.readFileSync(gradlePath, "utf8");
  const detected =
    gradleSrc.match(/applicationId\s*=?\s*["']([^"']+)["']/)?.[1] ||
    gradleSrc.match(/namespace\s*=?\s*["']([^"']+)["']/)?.[1];
  if (detected) oldAndroidId = detected;
}

const newId = cfg.appId;
const newName = cfg.appName;       // launcher / activity app name  → app_name only
const newStoreName = cfg.STORE_NAME; // brand store name → capacitor appName + STORE_NAME
console.log(`\nRebrand: ${oldId}  →  ${newId}`);
console.log(`  launcher app_name → "${newName}"  (was "${oldName}" in capacitor.config.ts)`);
console.log(`  store name        → "${newStoreName}"`);
if (oldAndroidId !== oldId) {
  console.log(
    `\n⚠ Native package (${oldAndroidId}) differs from capacitor.config.ts appId\n` +
      `  (${oldId}). Using the ${gradleFile} value for the Android files; both\n` +
      `  converge on ${newId} after this run.`,
  );
}
console.log("");

// ── 3. Prepare all edits in memory (verify every pattern before writing) ────
const edits = []; // { file, content }
const problems = [];

function planEdit(file, transforms) {
  const full = path.join(ROOT, file);
  if (!fs.existsSync(full)) {
    problems.push(`${file}: file not found`);
    return;
  }
  const original = fs.readFileSync(full, "utf8");
  let content = original;
  for (const t of transforms) {
    if (!t.pattern.test(content)) {
      if (t.optional) continue;
      problems.push(`${file}: expected pattern not found → ${t.describe}`);
      continue;
    }
    content = content.replace(t.pattern, t.replacement);
  }
  // Every transform is idempotent, so an unchanged file simply needs no write.
  if (content !== original) edits.push({ file: full, content });
}

// 3.1 capacitor.config.ts
planEdit("capacitor.config.ts", [
  {
    pattern: /appId:\s*["'][^"']+["']/,
    replacement: `appId: "${newId}"`,
    describe: "appId",
  },
  {
    pattern: /appName:\s*["'][^"']+["']/,
    replacement: `appName: "${newStoreName}"`,
    describe: "appName",
  },
]);

// 3.2 AndroidManifest.xml — scoped to the <manifest> tag so it can't hit
// anything else. Optional: AGP 8 dropped the package attribute entirely, and a
// manifest without it must not block the run.
planEdit("android/app/src/main/AndroidManifest.xml", [
  {
    pattern: /(<manifest[^>]*\bpackage=")[^"]*(")/,
    replacement: `$1${newId}$2`,
    describe: "manifest package attribute",
    optional: true,
  },
]);

// 3.3 strings.xml — app_name, title_activity_main, package_name, custom_url_scheme
planEdit("android/app/src/main/res/values/strings.xml", [
  {
    pattern: /(<string name="app_name">)[^<]*(<\/string>)/,
    replacement: `$1${newName}$2`,
    describe: "app_name",
  },
  {
    pattern: /(<string name="title_activity_main">)[^<]*(<\/string>)/,
    replacement: `$1${newName}$2`,
    describe: "title_activity_main",
  },
  {
    pattern: /(<string name="package_name">)[^<]*(<\/string>)/,
    replacement: `$1${newId}$2`,
    describe: "package_name",
  },
  {
    pattern: /(<string name="custom_url_scheme">)[^<]*(<\/string>)/,
    replacement: `$1${newId}$2`,
    describe: "custom_url_scheme",
  },
]);

// 3.4 android/app/build.gradle — namespace, applicationId, versionCode/Name.
// Value-agnostic patterns: they capture the assignment prefix and rewrite only
// the value, so they work whatever the current package is and preserve both
// Groovy (`namespace "x"`) and Kotlin (`namespace = "x"`) DSL styles.
planEdit(gradleFile, [
  {
    pattern: /(namespace\s*=?\s*)"[^"]*"/,
    replacement: `$1"${newId}"`,
    describe: "namespace",
  },
  {
    pattern: /(applicationId\s*=?\s*)"[^"]*"/,
    replacement: `$1"${newId}"`,
    describe: "applicationId",
  },
  {
    pattern: /(versionCode\s*=?\s*)\d+/,
    replacement: `$1${cfg.versionCode}`,
    describe: "versionCode",
  },
  {
    pattern: /(versionName\s*=?\s*)"[^"]*"/,
    replacement: `$1"${cfg.versionName}"`,
    describe: "versionName",
  },
]);

// 3.5 src/config/constants.js — appid, STORE_NAME, app_name (+ optional keys)
const constantsTransforms = [
  {
    pattern: /appid:\s*["'][^"']*["']/,
    replacement: `appid: "${newId}"`,
    describe: "appid",
  },
  {
    pattern: /STORE_NAME:\s*["'][^"']*["']/,
    replacement: `STORE_NAME: "${newStoreName}"`,
    describe: "STORE_NAME",
  },
  {
    pattern: /app_name:\s*["'][^"']*["']/,
    replacement: `app_name: "${newName}"`,
    describe: "app_name",
  },
];
if (cfg.STORE_ID !== undefined)
  constantsTransforms.push({
    pattern: /STORE_ID:\s*\d+/,
    replacement: `STORE_ID: ${cfg.STORE_ID}`,
    describe: "STORE_ID",
  });
if (cfg.THEME_ID !== undefined)
  constantsTransforms.push({
    pattern: /THEME_ID:\s*\d+/,
    replacement: `THEME_ID: ${cfg.THEME_ID}`,
    describe: "THEME_ID",
  });
if (cfg.BRANCH !== undefined) {
  constantsTransforms.push({
    // \b so this does NOT match the "BRANCH:" inside "DEFAULT_BRANCH:"
    pattern: /\bBRANCH:\s*["'][^"']*["']/,
    replacement: `BRANCH: "${cfg.BRANCH}"`,
    describe: "BRANCH",
  });
  constantsTransforms.push({
    pattern: /DEFAULT_BRANCH:\s*["'][^"']*["']/,
    replacement: `DEFAULT_BRANCH: "${cfg.BRANCH}"`,
    describe: "DEFAULT_BRANCH",
  });
}
if (cfg.appleid !== undefined)
  constantsTransforms.push({
    pattern: /appleid:\s*["'][^"']*["']/,
    replacement: `appleid: "${cfg.appleid}"`,
    describe: "appleid",
  });
planEdit("src/config/constants.js", constantsTransforms);

// 3.6 android assets capacitor.config.json (regenerated by cap sync, but keep
// it consistent so a build without a sync still carries the right identity)
const assetsCfgFile = "android/app/src/main/assets/capacitor.config.json";
if (fs.existsSync(path.join(ROOT, assetsCfgFile))) {
  planEdit(assetsCfgFile, [
    {
      pattern: /"appId":\s*"[^"]*"/,
      replacement: `"appId": "${newId}"`,
      describe: "appId",
    },
    {
      pattern: /"appName":\s*"[^"]*"/,
      replacement: `"appName": "${newStoreName}"`,
      describe: "appName",
    },
  ]);
}

// 3.7 Java sources — rewrite package declaration; folder move happens on write.
// Keyed off the DETECTED native package, not the Capacitor appId. Only relevant
// when that package actually changes; if it already equals newId there is
// nothing to move, so skip entirely (a missing java dir must NOT block a run
// that only changes names/branch).
const JAVA_ROOT = path.join(ROOT, "android/app/src/main/java");
const oldJavaDir = path.join(JAVA_ROOT, ...oldAndroidId.split("."));
const newJavaDir = path.join(JAVA_ROOT, ...newId.split("."));
// \uFEFF? tolerates a UTF-8 BOM on the first line.
const PKG_DECL = /^\uFEFF?[ \t]*package\s+[\w.]+\s*;/m;

// Collect .java paths relative to `dir`, including any nested sub-packages.
function collectJava(dir, base = "") {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const relPath = base ? `${base}/${entry.name}` : entry.name;
    if (entry.isDirectory()) out.push(...collectJava(path.join(dir, entry.name), relPath));
    else if (entry.name.endsWith(".java")) out.push(relPath);
  }
  return out;
}

let javaFiles = [];
if (oldAndroidId !== newId) {
  if (fs.existsSync(oldJavaDir)) {
    javaFiles = collectJava(oldJavaDir);
    for (const f of javaFiles) {
      const full = path.join(oldJavaDir, f);
      if (!PKG_DECL.test(fs.readFileSync(full, "utf8"))) {
        problems.push(`${rel(full)}: no "package …;" declaration found`);
      }
    }
  } else if (!fs.existsSync(newJavaDir)) {
    problems.push(`Java source dir not found: ${rel(oldJavaDir)}`);
  }
}

// ── 4. Abort if anything didn't match ────────────────────────────────────────
if (problems.length) {
  console.error("✖ Aborted — no files were changed. Problems:\n");
  problems.forEach((p) => console.error("  • " + p));
  process.exit(1);
}

// Decided after planning, so it reflects every file the script touches — not
// just capacitor.config.ts. Any drift anywhere still gets fixed.
if (!edits.length && !javaFiles.length) {
  console.log("Nothing to do — every file already matches the config.");
  process.exit(0);
}

// ── 5. Write everything ──────────────────────────────────────────────────────
for (const e of edits) {
  fs.writeFileSync(e.file, e.content, "utf8");
  console.log(`✔ updated  ${rel(e.file)}`);
}

// Move java package folder + rewrite package declarations
if (javaFiles.length) {
  for (const f of javaFiles) {
    const from = path.join(oldJavaDir, f);
    const to = path.join(newJavaDir, f);
    // A file in a sub-package keeps that suffix: <newId>.<sub.pkg>
    const subPkg = path.dirname(f).split("/").filter((s) => s && s !== ".");
    const pkg = [newId, ...subPkg].join(".");
    const src = fs.readFileSync(from, "utf8").replace(PKG_DECL, `package ${pkg};`);
    fs.mkdirSync(path.dirname(to), { recursive: true });
    fs.writeFileSync(to, src, "utf8");
    fs.unlinkSync(from);
    console.log(`✔ moved    ${rel(from)} → ${rel(to)}`);
  }
  // Clean now-empty old package dirs. Two separate passes on purpose: pruning
  // downward and upward in one recursion lets a child frame delete the dir its
  // parent frame is still about to read.
  const pruneDown = (dir) => {
    if (!fs.existsSync(dir)) return;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory()) pruneDown(path.join(dir, e.name));
    }
    if (fs.readdirSync(dir).length === 0) fs.rmdirSync(dir);
  };
  pruneDown(oldJavaDir);
  let dir = path.dirname(oldJavaDir);
  while (dir !== JAVA_ROOT && fs.existsSync(dir) && fs.readdirSync(dir).length === 0) {
    fs.rmdirSync(dir);
    dir = path.dirname(dir);
  }
}

// ── 6. Post-run checklist (things a script cannot do for you) ────────────────
console.log(`\n✅ Rebranded to ${newId} ("${newName}") v${cfg.versionName} (code ${cfg.versionCode})\n`);
console.log("── REQUIRED next steps ─────────────────────────────────────────");

const gsPath = path.join(ROOT, "android/app/google-services.json");
if (fs.existsSync(gsPath)) {
  const gs = fs.readFileSync(gsPath, "utf8");
  if (gs.includes(`"${newId}"`)) {
    console.log("  1. google-services.json already contains the new package ✔");
  } else {
    console.log(
      `  1. ⚠ REPLACE android/app/google-services.json — it does NOT contain\n` +
        `     ${newId}. Add an Android app with this package in the brand's\n` +
        `     Firebase project and download its google-services.json,\n` +
        `     otherwise the Android build FAILS (No matching client found)\n` +
        `     and push notifications won't work.`,
    );
  }
}
console.log(
  "  2. ⚠ Check the signing keystore in android/app/build.gradle\n" +
    "     (signingConfigs.release) — each brand should ship with its own\n" +
    "     keystore for Play Store releases.",
);
console.log(
  "  3. Rebuild:  npm run build && npx cap sync android\n" +
    "     then build/run from Android Studio (Sync Project when prompted).",
);
console.log(
  "  4. If the brand uses a different backend store, activate STORE_ID /\n" +
    "     BRANCH in scripts/rebrand.config.json (remove the underscore) and\n" +
    "     re-run — or edit src/config/constants.js manually.",
);
console.log("────────────────────────────────────────────────────────────────\n");
